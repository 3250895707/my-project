function y=phi(x)
    y = x;
    for ind = 1:length(x)
        if x(ind)>1
            y(ind)=1;
        elseif x(ind)<-1
            y(ind)=-1;
        end
    end
end