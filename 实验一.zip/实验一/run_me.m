clear all
close all
clc

k=2;
L=[
    0.5 -0.5 0 0;
    -0.5 0.8 -0.1 -0.2;
    0 -0.1 0.8 -0.7;
    0 -0.2 -0.7 0.9];
D=[
    0.5 0 0 0;
    0 0.8 0 0;
    0 0 0.8 0;
    0 0 0 0.9];
A=[
    0 0.5 0 0;
    0.5 0 0.1 0.2;
    0 0.1 0 0.7;
    0 0.2 0.7 0];


u = [2.5;10.2;3.7;6.8];
N = size(L,2);


%parameter tunning  0<tau/epsilon<=1 
alpha=0.1;   %alpha С�����ݷֱ���
 

tau = 0.99;
h=0.6;



 


num_of_iteration = 400;


x  = zeros(num_of_iteration,4);
x(1,:) = 10*[1,2,3,5];
y = zeros(num_of_iteration,4);
z = zeros(num_of_iteration,4);


z(1,:) = g(x(1,:) + u'/alpha);


s = zeros(num_of_iteration,4);
s(1,:) = y(1,:) + z(1,:);
tic
 for ind =1:num_of_iteration-1
%  ind
 
 x_vec = (x(ind,:))';
 y_vec = (y(ind,:))';
 s_vec = (s(ind,:))';

 x_vec = x_vec +tau*h*(-s_vec+k*ones(4,1)/N-L*x_vec);
 y_vec = y_vec - tau*(L*s_vec);
 z_vec = g(x_vec+u/alpha);

 x(ind+1,:) =  x_vec';
 y(ind+1,:) = y_vec';
 z(ind+1,:) = z_vec';
 s(ind+1,:) = y_vec'+z_vec';
 
 end 
toc

iter_vec = (0:num_of_iteration-1)';

% ͼ��1: s����������A1-A4��ǩ��
figure
plot(iter_vec, s(:,1), 'DisplayName', 'A1'); hold on;
plot(iter_vec, s(:,2), 'DisplayName', 'A2');
plot(iter_vec, s(:,3), 'DisplayName', 'A3');
plot(iter_vec, s(:,4), 'DisplayName', 'A4');
xlabel('iteration')
ylabel('s_i[k]')
legend('Location','best')


% ͼ��2: x����������A1-A4��ǩ��
figure
plot(iter_vec, x(:,1), 'DisplayName', 'A1'); hold on;
plot(iter_vec, x(:,2), 'DisplayName', 'A2');
plot(iter_vec, x(:,3), 'DisplayName', 'A3');
plot(iter_vec, x(:,4), 'DisplayName', 'A4');
xlabel('iteration')
ylabel('x_i[k]')
legend('Location','best')


% ͼ��3: y����������A1-A4��ǩ��
figure
plot(iter_vec, y(:,1), 'DisplayName', 'A1'); hold on;
plot(iter_vec, y(:,2), 'DisplayName', 'A2');
plot(iter_vec, y(:,3), 'DisplayName', 'A3');
plot(iter_vec, y(:,4), 'DisplayName', 'A4');
xlabel('iteration')
ylabel('y_i[k]')
legend('Location','best')


% ͼ��4: z����������ԭ����z1-z4��ǩ��
figure('Position', [500, 500, 500, 400]);

subplot(2,2,1);
plot(iter_vec, z(:,1));
xlabel('iteration')

legend('z_1')

subplot(2,2,2);
plot(iter_vec, z(:,2));
xlabel('iteration')

legend('z_2')

subplot(2,2,3);
plot(iter_vec, z(:,3));
xlabel('iteration')

legend('z_3')

subplot(2,2,4);
plot(iter_vec, z(:,4));
xlabel('iteration')

legend('z_4')


save all_data





 
