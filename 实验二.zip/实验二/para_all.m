figure;
hold on;

% 加载并绘制每条曲线（线宽保持1.0）
load('para1_data.mat'); 
plot(iter_vec, sum_z, 'LineStyle', '-', 'LineWidth', 1.0, 'DisplayName', sprintf('$\\tau=%.2f, h=%.2f$', tau, h));

load('para2_data.mat');
plot(iter_vec, sum_z, 'LineStyle', '--', 'LineWidth', 1.0, 'DisplayName', sprintf('$\\tau=%.2f, h=%.2f$', tau, h));

load('para3_data.mat'); 
plot(iter_vec, sum_z, 'LineStyle', '-', 'LineWidth', 1.0, 'DisplayName', sprintf('$\\tau=%.2f, h=%.2f$', tau, h));

load('para4_data.mat');
plot(iter_vec, sum_z, 'LineStyle', '--', 'LineWidth', 1.0, 'DisplayName', sprintf('$\\tau=%.2f, h=%.2f$', tau, h));

load('para5_data.mat'); 
plot(iter_vec, sum_z, 'LineStyle', '-', 'LineWidth', 1.0, 'DisplayName', sprintf('$\\tau=%.2f, h=%.2f$', tau, h));

load('para6_data.mat');
plot(iter_vec, sum_z, 'LineStyle', '--', 'LineWidth', 1.0, 'DisplayName', sprintf('$\\tau=%.2f, h=%.2f$', tau, h));

load('para7_data.mat'); 
plot(iter_vec, sum_z, 'LineStyle', '-', 'LineWidth', 1.0, 'DisplayName', sprintf('$\\tau=%.2f, h=%.2f$', tau, h));

% 统一设置
xlabel('Iteration', 'Interpreter', 'latex');
ylabel('$\sum_{i=1}^{N} z_i[k]$', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
set(gca, 'FontSize', 12);

% 设置横坐标范围0-5000
xlim([0 5000]);  % 新增此行

% 关键修改：关闭网格但保留坐标框
box on;    % 确保坐标框显示
grid off;  % 关闭网格线

% 优化导出
set(gcf, 'Color', 'w'); % 白色背景
set(gca, 'LooseInset', get(gca, 'TightInset')); % 紧凑布局
print('para', '-depsc2', '-r600', '-painters', '-loose');