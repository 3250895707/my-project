clear all
close all
clc

k=2;
L=[
    0.5 -0.5 0 0;
    -0.5 0.8 -0.1 -0.2;
    0 -0.1 0.8 -0.7;
    0 -0.2 -0.7 0.9];
D=[
    0.5 0 0 0;
    0 0.8 0 0;
    0 0 0.8 0;
    0 0 0 0.9];
A=[
    0 0.5 0 0;
    0.5 0 0.1 0.2;
    0 0.1 0 0.7;
    0 0.2 0.7 0];


u = [2.5;10.2;3.7;6.8];
N = size(L,2);


%parameter tunning  0<tau/epsilon<=1 
alpha=0.1;   %alpha С�����ݷֱ���
 

tau = 0.2;
h=0.2;



 


num_of_iteration = 40000;


x  = zeros(num_of_iteration,4);
x(1,:) = 10*[1,2,3,5];
y = zeros(num_of_iteration,4);
z = zeros(num_of_iteration,4);


z(1,:) = g(x(1,:) + u'/alpha);


s = zeros(num_of_iteration,4);
s(1,:) = y(1,:) + z(1,:);
 for ind =1:num_of_iteration-1
%  ind
 
 x_vec = (x(ind,:))';
 y_vec = (y(ind,:))';
 s_vec = (s(ind,:))';

 x_vec = x_vec +tau*h*(-s_vec+k*ones(4,1)/N-L*x_vec);
 y_vec = y_vec - tau*(L*s_vec);
 z_vec = g(x_vec+u/alpha);

 x(ind+1,:) =  x_vec';
 y(ind+1,:) = y_vec';
 z(ind+1,:) = z_vec';
 s(ind+1,:) = y_vec'+z_vec';
 end
 
 iter_vec = (0:num_of_iteration-1)';
 figure
 plot(iter_vec,s);
 xlabel('iteration')
 ylabel('s');
 
 figure
 plot(iter_vec,x);
 xlabel('iteration')
 ylabel('x');
 
 
 figure
 plot(iter_vec,y);
 xlabel('iteration')
 ylabel('y')

 figure('Position', [500, 500, 500, 400]);  % Adjust width and height as needed

subplot(2,2,1);
plot(iter_vec, z(:,1));
xlabel('iteration')
%ylabel('z1')
legend('z1')

subplot(2,2,2);
plot(iter_vec, z(:,2));
xlabel('iteration')
%ylabel('z2')
legend('z2')

subplot(2,2,3);
plot(iter_vec, z(:,3));
xlabel('iteration')
%ylabel('z3')
legend('z3')

subplot(2,2,4);
plot(iter_vec, z(:,4));
xlabel('iteration')
%ylabel('z4')
legend('z4')

figure
sum_z = zeros(num_of_iteration,1);
for ind = 1:num_of_iteration
    sum_z(ind) = sum(z(ind,:));
end

plot(iter_vec,sum_z);
xlabel('t')
ylabel('sumz');







 
