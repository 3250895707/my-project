clear all
close all
clc
load para1_data
plot(iter_vec,sum_z)
clear all
hold on 
load para2_data
plot(iter_vec,sum_z)
clear all
hold on 
load para3_data
plot(iter_vec,sum_z)
clear all
hold on 
load para4_data
plot(iter_vec,sum_z)
clear all
hold on 
load para5_data
plot(iter_vec,sum_z)
clear all
hold on 
load para6_data
plot(iter_vec,sum_z)
clear all
hold on 
load para7_data
plot(iter_vec,sum_z)